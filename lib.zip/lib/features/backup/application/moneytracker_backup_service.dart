import 'dart:convert';

import '../../settings/domain/entities/app_settings.dart';
import '../../accounts/domain/entities/finance_account.dart';
import '../../transactions/data/models/transaction_record.dart';
import '../../transactions/domain/entities/transaction_entry.dart';

class MoneyTrackerBackupData {
  const MoneyTrackerBackupData({required this.transactions, required this.settings, required this.accounts});

  final List<TransactionEntry> transactions;
  final AppSettings settings;
  final List<FinanceAccount> accounts;
}

abstract final class MoneyTrackerBackupService {
  static const schemaVersion = 2;
  static const format = 'moneytrackerpro-backup';

  static String encode({
    required List<TransactionEntry> transactions,
    required AppSettings settings,
    required List<FinanceAccount> accounts,
  }) {
    final payload = <String, dynamic>{
      'format': format,
      'schemaVersion': schemaVersion,
      'exportedAt': DateTime.now().toUtc().toIso8601String(),
      'settings': {
        'displayName': settings.displayName,
        'monthlyBudget': settings.monthlyBudget,
        'budgetAlertsEnabled': settings.budgetAlertsEnabled,
      },
      'accounts': accounts
          .map((account) => {'id': account.id, 'name': account.name, 'type': account.type.name})
          .toList(),
      'transactions': transactions
          .map(TransactionRecord.fromEntity)
          .map((record) => record.toJson())
          .toList(),
    };
    return const JsonEncoder.withIndent('  ').convert(payload);
  }

  static MoneyTrackerBackupData decode(String source) {
    try {
      final json = jsonDecode(source) as Map<String, dynamic>;
      if (json['format'] != format) {
        throw const BackupFormatException('This is not a MoneyTracker Pro backup.');
      }
      final version = json['schemaVersion'] as int;
      if (version < 1 || version > schemaVersion) {
        throw BackupFormatException('Unsupported backup version: ${json['schemaVersion']}.');
      }

      final settingsJson = json['settings'] as Map<String, dynamic>;
      final settings = AppSettings(
        displayName: settingsJson['displayName'] as String,
        monthlyBudget: (settingsJson['monthlyBudget'] as num).toDouble(),
        budgetAlertsEnabled: settingsJson['budgetAlertsEnabled'] as bool,
      );
      if (settings.displayName.trim().length < 2 || settings.monthlyBudget <= 0) {
        throw const BackupFormatException('Backup settings contain invalid values.');
      }

      final transactionJson = json['transactions'] as List<dynamic>;
      final transactions = transactionJson
          .map((item) => TransactionRecord.fromJson(item as Map<String, dynamic>).toEntity())
          .toList();

      final accounts = version == 1
          ? const <FinanceAccount>[FinanceAccount.cash()]
          : (json['accounts'] as List<dynamic>).map((item) {
              final account = item as Map<String, dynamic>;
              return FinanceAccount(
                id: account['id'] as String,
                name: account['name'] as String,
                type: FinanceAccountType.values.byName(account['type'] as String),
              );
            }).toList();
      if (accounts.isEmpty || accounts.map((item) => item.id).toSet().length != accounts.length) {
        throw const BackupFormatException('Backup contains invalid accounts.');
      }
      final accountIds = accounts.map((item) => item.id).toSet();
      if (transactions.any((item) => !accountIds.contains(item.accountId))) {
        throw const BackupFormatException('A transaction references an account missing from the backup.');
      }

      final ids = transactions.map((item) => item.id).toSet();
      if (ids.length != transactions.length) {
        throw const BackupFormatException('Backup contains duplicate transaction IDs.');
      }
      if (transactions.any((item) => item.title.trim().isEmpty || item.amount <= 0)) {
        throw const BackupFormatException('Backup contains invalid transactions.');
      }

      return MoneyTrackerBackupData(
        transactions: List.unmodifiable(transactions),
        settings: settings,
        accounts: List.unmodifiable(accounts),
      );
    } on BackupFormatException {
      rethrow;
    } on FormatException {
      throw const BackupFormatException('The pasted text is not valid JSON.');
    } on TypeError {
      throw const BackupFormatException('The backup structure is incomplete or invalid.');
    } on ArgumentError {
      throw const BackupFormatException('The backup contains an unsupported account type.');
    }
  }
}

class BackupFormatException implements Exception {
  const BackupFormatException(this.message);
  final String message;

  @override
  String toString() => message;
}

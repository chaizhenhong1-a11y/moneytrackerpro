import 'package:flutter/material.dart';

import '../../../accounts/domain/entities/finance_account.dart';

enum TransactionType { income, expense }

class TransactionEntry {
  const TransactionEntry({
    required this.id,
    required this.title,
    required this.category,
    required this.amount,
    required this.date,
    required this.type,
    required this.icon,
    required this.color,
    this.accountId = FinanceAccountIds.cash,
  });

  final String id;
  final String title;
  final String category;
  final double amount;
  final DateTime date;
  final TransactionType type;
  final IconData icon;
  final Color color;
  final String accountId;

  bool get isIncome => type == TransactionType.income;
  double get signedAmount => isIncome ? amount : -amount;
}

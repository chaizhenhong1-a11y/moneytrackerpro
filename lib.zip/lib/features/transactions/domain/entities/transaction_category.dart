import 'package:flutter/material.dart';

class TransactionCategory {
  const TransactionCategory({
    required this.id,
    required this.name,
    required this.icon,
    required this.color,
  });

  final String id;
  final String name;
  final IconData icon;
  final Color color;
}

abstract final class TransactionCategories {
  static const values = <TransactionCategory>[
    TransactionCategory(
      id: 'food',
      name: 'Food & Drinks',
      icon: Icons.restaurant_rounded,
      color: Color(0xFFFF8B5C),
    ),
    TransactionCategory(
      id: 'transport',
      name: 'Transport',
      icon: Icons.directions_car_rounded,
      color: Color(0xFF5D9CEC),
    ),
    TransactionCategory(
      id: 'shopping',
      name: 'Shopping',
      icon: Icons.shopping_bag_rounded,
      color: Color(0xFFE96CB5),
    ),
    TransactionCategory(
      id: 'bills',
      name: 'Bills',
      icon: Icons.receipt_long_rounded,
      color: Color(0xFFF4B740),
    ),
    TransactionCategory(
      id: 'salary',
      name: 'Salary',
      icon: Icons.account_balance_wallet_rounded,
      color: Color(0xFF21B978),
    ),
    TransactionCategory(
      id: 'other',
      name: 'Other',
      icon: Icons.more_horiz_rounded,
      color: Color(0xFF8D8E9B),
    ),
  ];
}

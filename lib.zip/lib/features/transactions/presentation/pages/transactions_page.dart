import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../accounts/presentation/controllers/account_controller.dart';
import '../../../../core/utils/currency_formatter.dart';
import '../../../dashboard/presentation/controllers/dashboard_controller.dart';
import '../../domain/entities/transaction_entry.dart';
import '../widgets/add_transaction_sheet.dart';
import '../../../dashboard/presentation/widgets/transaction_tile.dart';

enum TransactionFilter { all, income, expense }
enum TransactionPeriod { thisMonth, lastMonth, all }

class TransactionsPage extends StatefulWidget {
  const TransactionsPage({required this.controller, required this.accountController, super.key});

  final DashboardController controller;
  final AccountController accountController;

  @override
  State<TransactionsPage> createState() => _TransactionsPageState();
}

class _TransactionsPageState extends State<TransactionsPage> {
  final _searchController = TextEditingController();
  TransactionFilter _filter = TransactionFilter.all;
  TransactionPeriod _period = TransactionPeriod.thisMonth;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([widget.controller, widget.accountController]),
      builder: (context, _) {
        final transactions = _filteredTransactions(widget.controller.transactions);
        final total = transactions.fold<double>(0, (sum, item) => sum + item.signedAmount);

        return Scaffold(
          appBar: AppBar(
            title: const Text('Transactions', style: TextStyle(fontWeight: FontWeight.w800)),
            actions: [
              IconButton(
                tooltip: 'Add transaction',
                onPressed: _openAddTransaction,
                icon: const Icon(Icons.add_circle_outline_rounded),
              ),
              const SizedBox(width: 8),
            ],
          ),
          body: RefreshIndicator(
            onRefresh: widget.controller.load,
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
              children: [
                _SummaryCard(count: transactions.length, total: total),
                const SizedBox(height: 18),
                TextField(
                  controller: _searchController,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    hintText: 'Search transactions',
                    prefixIcon: const Icon(Icons.search_rounded),
                    suffixIcon: _searchController.text.isEmpty
                        ? null
                        : IconButton(
                            onPressed: () {
                              _searchController.clear();
                              setState(() {});
                            },
                            icon: const Icon(Icons.close_rounded),
                          ),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: SegmentedButton<TransactionFilter>(
                    segments: const [
                      ButtonSegment(value: TransactionFilter.all, label: Text('All')),
                      ButtonSegment(value: TransactionFilter.income, label: Text('Income')),
                      ButtonSegment(value: TransactionFilter.expense, label: Text('Expense')),
                    ],
                    selected: {_filter},
                    onSelectionChanged: (value) => setState(() => _filter = value.first),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<TransactionPeriod>(
                  initialValue: _period,
                  decoration: InputDecoration(
                    labelText: 'Period',
                    prefixIcon: const Icon(Icons.calendar_month_outlined),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
                  ),
                  items: const [
                    DropdownMenuItem(value: TransactionPeriod.thisMonth, child: Text('This month')),
                    DropdownMenuItem(value: TransactionPeriod.lastMonth, child: Text('Last month')),
                    DropdownMenuItem(value: TransactionPeriod.all, child: Text('All time')),
                  ],
                  onChanged: (value) => setState(() => _period = value ?? _period),
                ),
                const SizedBox(height: 20),
                if (widget.controller.isLoading)
                  const Padding(
                    padding: EdgeInsets.all(40),
                    child: Center(child: CircularProgressIndicator()),
                  )
                else if (transactions.isEmpty)
                  const _NoResults()
                else
                  ..._buildGroupedTransactions(transactions),
              ],
            ),
          ),
        );
      },
    );
  }

  List<TransactionEntry> _filteredTransactions(List<TransactionEntry> items) {
    final query = _searchController.text.trim().toLowerCase();
    return items.where((item) {
      final matchesQuery = query.isEmpty ||
          item.title.toLowerCase().contains(query) ||
          item.category.toLowerCase().contains(query);
      final matchesFilter = switch (_filter) {
        TransactionFilter.all => true,
        TransactionFilter.income => item.isIncome,
        TransactionFilter.expense => !item.isIncome,
      };
      final now = DateTime.now();
      final lastMonth = DateTime(now.year, now.month - 1);
      final matchesPeriod = switch (_period) {
        TransactionPeriod.thisMonth => item.date.year == now.year && item.date.month == now.month,
        TransactionPeriod.lastMonth => item.date.year == lastMonth.year && item.date.month == lastMonth.month,
        TransactionPeriod.all => true,
      };
      return matchesQuery && matchesFilter && matchesPeriod;
    }).toList();
  }

  List<Widget> _buildGroupedTransactions(List<TransactionEntry> transactions) {
    final widgets = <Widget>[];
    DateTime? previousDay;

    for (final transaction in transactions) {
      final day = DateTime(transaction.date.year, transaction.date.month, transaction.date.day);
      if (previousDay != day) {
        widgets.add(
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 8, 4, 10),
            child: Text(
              _dateGroupLabel(day),
              style: const TextStyle(color: AppColors.textSecondary, fontSize: 12, fontWeight: FontWeight.w700),
            ),
          ),
        );
        previousDay = day;
      }
      widgets.add(
        Dismissible(
          key: ValueKey('history_${transaction.id}'),
          direction: DismissDirection.endToStart,
          confirmDismiss: (_) => _confirmDelete(transaction),
          onDismissed: (_) => _deleteWithUndo(transaction),
          background: Container(
            margin: const EdgeInsets.only(bottom: 11),
            padding: const EdgeInsets.only(right: 22),
            alignment: Alignment.centerRight,
            decoration: BoxDecoration(color: AppColors.expense, borderRadius: BorderRadius.circular(24)),
            child: const Icon(Icons.delete_outline_rounded, color: Colors.white),
          ),
          child: TransactionTile(
            transaction: transaction,
            onTap: () => _openEditTransaction(transaction),
          ),
        ),
      );
    }
    return widgets;
  }

  String _dateGroupLabel(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    if (date == today) return 'TODAY';
    if (date == today.subtract(const Duration(days: 1))) return 'YESTERDAY';
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${date.day} ${months[date.month - 1]} ${date.year}';
  }

  Future<void> _openAddTransaction() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AddTransactionSheet(
        controller: widget.controller,
        accounts: widget.accountController.accounts,
      ),
    );
  }

  Future<void> _openEditTransaction(TransactionEntry transaction) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AddTransactionSheet(
        controller: widget.controller,
        accounts: widget.accountController.accounts,
        transaction: transaction,
      ),
    );
  }

  Future<bool> _confirmDelete(TransactionEntry transaction) async {
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Delete transaction?'),
            content: Text('${transaction.title} will be permanently removed.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
            ],
          ),
        ) ??
        false;
  }

  Future<void> _deleteWithUndo(TransactionEntry transaction) async {
    await widget.controller.deleteTransaction(transaction.id);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text('${transaction.title} deleted.'),
          action: SnackBarAction(
            label: 'UNDO',
            onPressed: () => widget.controller.restoreTransaction(transaction),
          ),
        ),
      );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.count, required this.total});

  final int count;
  final double total;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF826CEB), AppColors.primaryDark]),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Filtered total', style: TextStyle(color: Color(0xFFDCD6FF))),
                const SizedBox(height: 5),
                Text(
                  CurrencyFormatter.myr(total, showSign: true),
                  style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w800),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: .14), borderRadius: BorderRadius.circular(18)),
            child: Text('$count records', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}

class _NoResults extends StatelessWidget {
  const _NoResults();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 48),
      child: Column(
        children: [
          Icon(Icons.search_off_rounded, color: AppColors.textSecondary, size: 42),
          SizedBox(height: 12),
          Text('No matching transactions', style: TextStyle(fontWeight: FontWeight.w700)),
          SizedBox(height: 5),
          Text('Try another search or filter.', style: TextStyle(color: AppColors.textSecondary)),
        ],
      ),
    );
  }
}

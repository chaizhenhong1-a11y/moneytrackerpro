import 'package:flutter/foundation.dart';

import '../../../transactions/domain/entities/transaction_category.dart';
import '../../../transactions/domain/entities/transaction_entry.dart';
import '../../../transactions/domain/repositories/transaction_repository.dart';

enum DashboardStatus { initial, loading, ready, failure }

class DashboardController extends ChangeNotifier {
  DashboardController(this._repository);

  final TransactionRepository _repository;
  List<TransactionEntry> _transactions = const [];
  DashboardStatus _status = DashboardStatus.initial;
  String? _errorMessage;

  List<TransactionEntry> get transactions => _transactions;
  DashboardStatus get status => _status;
  String? get errorMessage => _errorMessage;
  bool get isLoading => _status == DashboardStatus.loading;
  bool get hasError => _status == DashboardStatus.failure;

  double get income => _transactions
      .where((item) => item.isIncome)
      .fold(0, (total, item) => total + item.amount);

  double get expense => _transactions
      .where((item) => !item.isIncome)
      .fold(0, (total, item) => total + item.amount);

  double get balance => income - expense;

  Future<void> load() async {
    _status = DashboardStatus.loading;
    _errorMessage = null;
    notifyListeners();

    try {
      _transactions = await _repository.getAll();
      _status = DashboardStatus.ready;
    } catch (_) {
      _status = DashboardStatus.failure;
      _errorMessage = 'Unable to load your transactions.';
    }
    notifyListeners();
  }

  Future<bool> addTransaction({
    required String title,
    required double amount,
    required TransactionType type,
    required TransactionCategory category,
    required DateTime date,
    String accountId = 'account_cash',
  }) async {
    try {
      await _repository.create(
        TransactionEntry(
          id: DateTime.now().microsecondsSinceEpoch.toString(),
          title: title.trim(),
          category: category.name,
          amount: amount,
          date: date,
          type: type,
          icon: category.icon,
          color: category.color,
          accountId: accountId,
        ),
      );
      _transactions = await _repository.getAll();
      _status = DashboardStatus.ready;
      notifyListeners();
      return true;
    } catch (_) {
      _errorMessage = 'Unable to save the transaction.';
      notifyListeners();
      return false;
    }
  }

  Future<bool> updateTransaction({
    required String id,
    required String title,
    required double amount,
    required TransactionType type,
    required TransactionCategory category,
    required DateTime date,
    String accountId = 'account_cash',
  }) async {
    try {
      await _repository.update(
        TransactionEntry(
          id: id,
          title: title.trim(),
          category: category.name,
          amount: amount,
          date: date,
          type: type,
          icon: category.icon,
          color: category.color,
          accountId: accountId,
        ),
      );
      _transactions = await _repository.getAll();
      _errorMessage = null;
      _status = DashboardStatus.ready;
      notifyListeners();
      return true;
    } catch (_) {
      _errorMessage = 'Unable to update the transaction.';
      notifyListeners();
      return false;
    }
  }

  Future<void> deleteTransaction(String id) async {
    final previous = _transactions;
    _transactions = _transactions.where((item) => item.id != id).toList(growable: false);
    notifyListeners();
    try {
      await _repository.delete(id);
      _transactions = await _repository.getAll();
      _errorMessage = null;
    } catch (_) {
      _transactions = previous;
      _errorMessage = 'Unable to delete the transaction.';
    }
    notifyListeners();
  }

  Future<bool> restoreTransaction(TransactionEntry transaction) async {
    try {
      await _repository.create(transaction);
      _transactions = await _repository.getAll();
      _errorMessage = null;
      notifyListeners();
      return true;
    } catch (_) {
      _errorMessage = 'Unable to restore the transaction.';
      notifyListeners();
      return false;
    }
  }

  Future<bool> replaceAllTransactions(List<TransactionEntry> transactions) async {
    try {
      await _repository.replaceAll(transactions);
      _transactions = await _repository.getAll();
      _errorMessage = null;
      _status = DashboardStatus.ready;
      notifyListeners();
      return true;
    } catch (_) {
      _errorMessage = 'Unable to replace transaction data.';
      notifyListeners();
      return false;
    }
  }
}

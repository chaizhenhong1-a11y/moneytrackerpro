import 'package:flutter/material.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../alerts/domain/services/financial_alert_service.dart';
import '../../../accounts/presentation/controllers/account_controller.dart';
import '../../../alerts/presentation/pages/alerts_page.dart';
import '../../../transactions/domain/entities/transaction_entry.dart';
import '../../../transactions/presentation/widgets/add_transaction_sheet.dart';
import '../../../settings/presentation/controllers/settings_controller.dart';
import '../controllers/dashboard_controller.dart';
import '../widgets/balance_card.dart';
import '../widgets/budget_progress_card.dart';
import '../widgets/spending_chart_card.dart';
import '../widgets/transaction_tile.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({
    required this.controller,
    required this.settingsController,
    required this.onShowTransactions,
    required this.accountController,
    super.key,
  });

  final DashboardController controller;
  final SettingsController settingsController;
  final VoidCallback onShowTransactions;
  final AccountController accountController;

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  DashboardController get _controller => widget.controller;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([_controller, widget.settingsController, widget.accountController]),
      builder: (context, _) {
        final alertCount = FinancialAlertService.generate(
          transactions: _controller.transactions,
          settings: widget.settingsController.settings,
        ).length;
        return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 120),
              sliver: SliverList.list(
                children: [
                  _DashboardHeader(
                    name: widget.settingsController.settings.displayName,
                    alertCount: alertCount,
                    onAlertsTap: _openAlerts,
                  ),
                  const SizedBox(height: 24),
                  BalanceCard(
                    balance: _controller.balance,
                    income: _controller.income,
                    expense: _controller.expense,
                  ),
                  const SizedBox(height: 16),
                  BudgetProgressCard(
                    spent: _currentMonthExpense,
                    budget: widget.settingsController.settings.monthlyBudget,
                  ),
                  const SizedBox(height: 25),
                  const _SectionHeader(title: 'Spending overview', action: 'This week'),
                  const SizedBox(height: 14),
                  SpendingChartCard(transactions: _controller.transactions),
                  const SizedBox(height: 24),
                  _SectionHeader(
                    title: 'Recent transactions',
                    action: 'See all',
                    onTap: widget.onShowTransactions,
                  ),
                  const SizedBox(height: 10),
                  if (_controller.isLoading)
                    const Padding(
                      padding: EdgeInsets.all(32),
                      child: Center(child: CircularProgressIndicator()),
                    )
                  else if (_controller.transactions.isEmpty)
                    const _EmptyTransactions()
                  else
                    ..._controller.transactions.map(
                      (item) => Dismissible(
                        key: ValueKey(item.id),
                        direction: DismissDirection.endToStart,
                        confirmDismiss: (_) => _confirmDelete(item),
                        background: Container(
                          margin: const EdgeInsets.only(bottom: 11),
                          padding: const EdgeInsets.only(right: 22),
                          alignment: Alignment.centerRight,
                          decoration: BoxDecoration(color: AppColors.expense, borderRadius: BorderRadius.circular(24)),
                          child: const Icon(Icons.delete_outline_rounded, color: Colors.white),
                        ),
                        onDismissed: (_) => _deleteWithUndo(item),
                        child: TransactionTile(
                          transaction: item,
                          onTap: () => _showEditTransactionSheet(item),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddTransactionSheet,
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        shape: const CircleBorder(),
        child: const Icon(Icons.add_rounded, size: 30),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        );
      },
    );
  }

  double get _currentMonthExpense {
    final now = DateTime.now();
    return _controller.transactions
        .where((item) => !item.isIncome && item.date.year == now.year && item.date.month == now.month)
        .fold(0, (sum, item) => sum + item.amount);
  }

  void _showAddTransactionSheet() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AddTransactionSheet(
        controller: _controller,
        accounts: widget.accountController.accounts,
      ),
    );
  }

  void _showEditTransactionSheet(TransactionEntry transaction) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AddTransactionSheet(
        controller: _controller,
        accounts: widget.accountController.accounts,
        transaction: transaction,
      ),
    );
  }

  void _openAlerts() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (context) => AlertsPage(
          dashboardController: _controller,
          settingsController: widget.settingsController,
        ),
      ),
    );
  }

  Future<bool> _confirmDelete(TransactionEntry transaction) async {
    return await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('Delete transaction?'),
            content: Text('${transaction.title} will be removed.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
              FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Delete')),
            ],
          ),
        ) ??
        false;
  }

  Future<void> _deleteWithUndo(TransactionEntry transaction) async {
    await _controller.deleteTransaction(transaction.id);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text('${transaction.title} deleted.'),
          action: SnackBarAction(
            label: 'UNDO',
            onPressed: () => _controller.restoreTransaction(transaction),
          ),
        ),
      );
  }
}

class _DashboardHeader extends StatelessWidget {
  const _DashboardHeader({required this.name, required this.alertCount, required this.onAlertsTap});

  final String name;
  final int alertCount;
  final VoidCallback onAlertsTap;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(color: AppColors.primarySoft, borderRadius: BorderRadius.circular(16)),
          child: const Icon(Icons.person_rounded, color: AppColors.primary, size: 30),
        ),
        const SizedBox(width: 13),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Good morning', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
              const SizedBox(height: 3),
              Text(name, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
        Stack(
          clipBehavior: Clip.none,
          children: [
            IconButton.filledTonal(onPressed: onAlertsTap, icon: const Icon(Icons.notifications_none_rounded)),
            if (alertCount > 0)
              Positioned(
                right: -2,
                top: -3,
                child: Container(
                  constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(color: AppColors.expense, shape: BoxShape.circle),
                  child: Text(alertCount > 9 ? '9+' : '$alertCount', style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800)),
                ),
              ),
          ],
        ),
      ],
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.title, required this.action, this.onTap});

  final String title;
  final String action;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700))),
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
            child: Row(
              children: [
                Text(action, style: TextStyle(color: onTap == null ? AppColors.textSecondary : AppColors.primary, fontWeight: FontWeight.w600)),
                if (onTap != null) const Icon(Icons.chevron_right_rounded, color: AppColors.primary, size: 18),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _EmptyTransactions extends StatelessWidget {
  const _EmptyTransactions();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(color: AppColors.primarySoft, shape: BoxShape.circle),
              child: const Icon(Icons.receipt_long_outlined, color: AppColors.primary),
            ),
            const SizedBox(height: 14),
            const Text('No transactions yet', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 5),
            const Text('Tap + to record your first transaction.', style: TextStyle(color: AppColors.textSecondary)),
          ],
        ),
      ),
    );
  }
}

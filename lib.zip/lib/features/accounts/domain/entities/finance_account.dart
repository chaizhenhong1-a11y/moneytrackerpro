enum FinanceAccountType { cash, bank, eWallet, savings }

abstract final class FinanceAccountIds {
  static const cash = 'account_cash';
}

class FinanceAccount {
  const FinanceAccount({required this.id, required this.name, required this.type});

  const FinanceAccount.cash()
      : id = FinanceAccountIds.cash,
        name = 'Cash',
        type = FinanceAccountType.cash;

  final String id;
  final String name;
  final FinanceAccountType type;
}

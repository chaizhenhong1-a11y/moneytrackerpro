import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';
import '../features/dashboard/data/dashboard_demo_data.dart';
import '../features/accounts/data/repositories/local_account_repository.dart';
import '../features/accounts/presentation/controllers/account_controller.dart';
import '../features/dashboard/presentation/controllers/dashboard_controller.dart';
import '../features/dashboard/presentation/pages/dashboard_page.dart';
import '../features/statistics/presentation/pages/statistics_page.dart';
import '../features/settings/data/repositories/local_settings_repository.dart';
import '../features/settings/presentation/controllers/settings_controller.dart';
import '../features/settings/presentation/pages/profile_page.dart';
import '../features/transactions/data/repositories/local_transaction_repository.dart';
import '../features/transactions/presentation/pages/transactions_page.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  late final DashboardController _controller;
  late final SettingsController _settingsController;
  late final AccountController _accountController;
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _controller = DashboardController(
      LocalTransactionRepository(seed: DashboardDemoData.transactions),
    )..load();
    _settingsController = SettingsController(LocalSettingsRepository())..load();
    _accountController = AccountController(LocalAccountRepository())..load();
  }

  @override
  void dispose() {
    _controller.dispose();
    _settingsController.dispose();
    _accountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: [
          DashboardPage(
            controller: _controller,
            settingsController: _settingsController,
            onShowTransactions: () => setState(() => _selectedIndex = 2),
            accountController: _accountController,
          ),
          StatisticsPage(controller: _controller),
          TransactionsPage(controller: _controller, accountController: _accountController),
          ProfilePage(
            controller: _settingsController,
            dashboardController: _controller,
            accountController: _accountController,
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) => setState(() => _selectedIndex = index),
        backgroundColor: Colors.white,
        indicatorColor: AppColors.primarySoft,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.pie_chart_outline_rounded),
            selectedIcon: Icon(Icons.pie_chart_rounded),
            label: 'Statistics',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long_rounded),
            label: 'Transactions',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline_rounded),
            selectedIcon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
